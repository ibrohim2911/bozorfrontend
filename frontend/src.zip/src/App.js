// import "./index.css";
import Header from './components/header';
import Catalog from './components/catalog';
import Produckts from './components/products';
function App() {
  return <>
  <Header />
  <Catalog />
  <Produckts/>
  </>;
}

export default App;
